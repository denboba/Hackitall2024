import 'package:flutter/material.dart';

class ColorConstant {
  static const Color buttonColor = Color.fromARGB(255, 196, 142, 221);
  static const Color backgroundColor = Color.fromARGB(255, 253, 247, 254);
  static const Color lightButtonColor = Color.fromARGB(255, 217, 206, 237);
}
